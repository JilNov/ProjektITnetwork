public class TestMain {
    public static void main(String[] args) {
        Questions questions = new Questions();
        Test test = new Test(questions.getQuestions());
        test.run();
    }
}