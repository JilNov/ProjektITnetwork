class Questions {
    private final Question[] questions;

    public Questions() {
        // Připravte si zde otázky a odpovědi
        Answer[] answers1 = {
                new Answer("A\n Řeknete jí, že chcete zprávu, vysvětlíte, co má ve zprávě být a denně ji budete kontrolovat.\n", AnswerColumn.S1),
                new Answer("B\n Dáte podřízené více času na to, aby úkol splnila.\n", AnswerColumn.S4),
                new Answer("C\n Řeknete jí, co od ní očekáváte, kdy chcete mít zprávu hotovou a proberete s ní, proč se se zprávou zpozdila.\n", AnswerColumn.S2),
                new Answer("D\n Promluvíte si s ní a vyzvete ji, aby práci dokončila.\n", AnswerColumn.S3)
        };

        Answer[] answers2 = {
                new Answer("A\n Řeknete mu, co je přesně potřeba a dohlédnete na jeho postup.\n", AnswerColumn.S1),
                new Answer("B\n Nabídnete mu svou pomoc a podpoříte jeho radost z toho, že se stal novým členem komise.\n", AnswerColumn.S3),
                new Answer("C\n Stanovíte požadavky na úpravu zprávy a informace, ale přijmete i jeho možné návrhy a podněty.\n", AnswerColumn.S2),
                new Answer("D\n Uvítáte ho v komisi, seznámíte s ostatními členy komise, kteří by mu mohli s vypracováním úkolu poradit.\n", AnswerColumn.S4)
        };

        Answer[] answers3 = {
                new Answer("A\n Budete na něj nadále dohlížet a sledovat jeho úsilí při plnění úkolu.\n", AnswerColumn.S1),
                new Answer("B\n Budete pokračovat v kontrole jeho práce a pokusíte se zjistit příčinu jeho chování a postojů k zadanému úkolu.\n", AnswerColumn.S2),
                new Answer("C\n Zapojíte ho do řešení problému, nabídnete pomoc a při dokončování úkolu přijmete i jeho myšlenky.\n", AnswerColumn.S3),
                new Answer("D\n Dáte mu vědět, že je to dúležitý úkol a nabídnete pomoc, kdykoli bude mít nějaké otázky nebo nejasnosti.\n", AnswerColumn.S4)
        };

        Answer[] answers4 = {
                new Answer("A\n Zdůrazníte nutnost lepšího výkonu a vyzvete skupinu, aby si své problémy vyřešila sama.\n ", AnswerColumn.S4),
                new Answer("B\n Ujistíte se, že práce bude včas a dobře splněna, ale zároveň si se skupinou promluvíte, abyste získal(a) její návrhy.\n", AnswerColumn.S2),
                new Answer("C\n Sdělíte skupině, co a kdy přesně od nich očekáváte, jaké budou důsledky, nezlepší-li se výkon a často budete kontrolovat její práci.\n", AnswerColumn.S1),
                new Answer("D\n Pomůžete skupině určit co je třeba udělat a stimulujete je k tomu, aby podnikly potřebné kroky.\n", AnswerColumn.S3)
        };

        Answer[] answers5 = {
                new Answer("A\n Zadáte ji úkol a vyslechnete její návrhy.\n", AnswerColumn.S2),
                new Answer("B\n Přidělíte jí úkol a necháte na ní, aby určila postup při jeho plnění.\n", AnswerColumn.S4),
                new Answer("C\n Proberete s ní úkol. Povzbudíte ji, aby úkol přijala vzhledem k jejím schopnostem a zkušenostem.\n", AnswerColumn.S3),
                new Answer("D\n Zadáte úkol a přesně určíte, co má dělat. Její práci budete pečlivě kontrolovat.\n", AnswerColumn.S1)
        };

        Answer[] answers6 = {
                new Answer("A\n ", AnswerColumn.S1),
                new Answer("B\n ", AnswerColumn.S4),
                new Answer("C\n ", AnswerColumn.S2),
                new Answer("D\n ", AnswerColumn.S3)
        };

        Answer[] answers7 = {
                new Answer("Odpověď A", AnswerColumn.S3),
                new Answer("Odpověď B", AnswerColumn.S1),
                new Answer("Odpověď C", AnswerColumn.S4),
                new Answer("Odpověď D", AnswerColumn.S2)
        };

        Answer[] answers8 = {
                new Answer("Odpověď A", AnswerColumn.S3),
                new Answer("Odpověď B", AnswerColumn.S2),
                new Answer("Odpověď C", AnswerColumn.S1),
                new Answer("Odpověď D", AnswerColumn.S4)
        };

        Answer[] answers9 = {
                new Answer("Odpověď A", AnswerColumn.S3),
                new Answer("Odpověď B", AnswerColumn.S2),
                new Answer("Odpověď C", AnswerColumn.S4),
                new Answer("Odpověď D", AnswerColumn.S1)
        };

        Answer[] answers10 = {
                new Answer("Odpověď A", AnswerColumn.S4),
                new Answer("Odpověď B", AnswerColumn.S1),
                new Answer("Odpověď C", AnswerColumn.S2),
                new Answer("Odpověď D", AnswerColumn.S3)
        };

        Answer[] answers11 = {
                new Answer("Odpověď A", AnswerColumn.S4),
                new Answer("Odpověď B", AnswerColumn.S1),
                new Answer("Odpověď C", AnswerColumn.S2),
                new Answer("Odpověď D", AnswerColumn.S3)
        };

        Answer[] answers12 = {
                new Answer("Odpověď A", AnswerColumn.S1),
                new Answer("Odpověď B", AnswerColumn.S3),
                new Answer("Odpověď C", AnswerColumn.S2),
                new Answer("Odpověď D", AnswerColumn.S4)
        };

        Answer[] answers13 = {
                new Answer("Odpověď A", AnswerColumn.S4),
                new Answer("Odpověď B", AnswerColumn.S1),
                new Answer("Odpověď C", AnswerColumn.S2),
                new Answer("Odpověď D", AnswerColumn.S3)
        };

        Answer[] answers14 = {
                new Answer("Odpověď A", AnswerColumn.S3),
                new Answer("Odpověď B", AnswerColumn.S2),
                new Answer("Odpověď C", AnswerColumn.S4),
                new Answer("Odpověď D", AnswerColumn.S1)
        };

        Answer[] answers15 = {
                new Answer("A\n ", AnswerColumn.S4),
                new Answer("Odpověď B", AnswerColumn.S3),
                new Answer("Odpověď C", AnswerColumn.S2),
                new Answer("Odpověď D", AnswerColumn.S1)
        };

        Answer[] answers16 = {
                new Answer("Odpověď A", AnswerColumn.S4),
                new Answer("Odpověď B", AnswerColumn.S1),
                new Answer("Odpověď C", AnswerColumn.S3),
                new Answer("Odpověď D", AnswerColumn.S2)
        };

        Answer[] answers17 = {
                new Answer("Odpověď A", AnswerColumn.S3),
                new Answer("Odpověď B", AnswerColumn.S1),
                new Answer("Odpověď C", AnswerColumn.S4),
                new Answer("Odpověď D", AnswerColumn.S2)
        };

        Answer[] answers18 = {
                new Answer("Odpověď A", AnswerColumn.S2),
                new Answer("Odpověď B", AnswerColumn.S1),
                new Answer("Odpověď C", AnswerColumn.S3),
                new Answer("Odpověď D", AnswerColumn.S4)
        };

        Answer[] answers19 = {
                new Answer("Odpověď A", AnswerColumn.S3),
                new Answer("Odpověď B", AnswerColumn.S2),
                new Answer("Odpověď C", AnswerColumn.S4),
                new Answer("Odpověď D", AnswerColumn.S1)
        };

        Answer[] answers20 = {
                new Answer("Odpověď A", AnswerColumn.S2),
                new Answer("Odpověď B", AnswerColumn.S4),
                new Answer("Odpověď C", AnswerColumn.S3),
                new Answer("Odpověď D", AnswerColumn.S1)
        };

        // Přidejte další otázky a odpovědi
        // ...

        questions = new Question[]{
                new Question("1.\n Požádal jste jednu z vašich podřízených,\n aby napsala zprávu o některém novém zařízení ve vašem oddělení.\n Obvykle úkoly plní včas, teď však zpráva stále není hotová.\n", answers1),
                new Question("2.\n Komise, která je složená ze členů různých oddělení a kterou vedete, pracuje na dokončení zprávy o celé sekci\n Do komise vám přidělili nového pracovníka. Do příštího týdne musí dokončit výpočty týkající se jeho oddělení,\n ale neví nic ani o požadavcích komise, ani o úpravě zprávy. O své roli v komisi by se rád dozvěděl více.\n", answers2),
                new Question("3.\n Nedávno jste začal(a) mít potíže s jedním z vašich podřízených. Projevuje nezájem o práci a jen díky vašemu neustálému pobízení byl úkol splněn.\n Podle vašich dřívějších zkušeností se domníváte, že asi neměl vše potřebné k tomu,\n aby splnil tak důležitý úkol, který jste mu zadal.\n", answers3),
                new Question("4.\n Vaše skupina obvykle pod vaším vedením pracuje efektivně.. Přes vaše neustálé vedení a pomoc se její výkon značně zhoršil.\n Aby se její výkon zlepšil, potřebuje více znalostí a zkušeností.\n Už i váš šéf se začal znepokojovat.\n", answers4),
                new Question("5.\n Na vaše oddělení se vztahuje omezení rozpočtu, je nutné provést konsolidaci.\n Požádáte zkušenou pracovnici vašeho oddělení, aby se tohoto úkolu ujala. Tato kolegině již pracovala na všech místech vašeho oddělení.\n V minulosti většinou ochotně pomohla. Ačkoli si myslíte, že je v jejích silách tento úkol zvládnout, zdá se, že závažnost úkolu ji leká.\n", answers5),
                new Question("Otázka 6", answers6),
                new Question("Otázka 7", answers7),
                new Question("Otázka 8", answers8),
                new Question("Otázka 9", answers9),
                new Question("Otázka 10", answers10),
                new Question("Otázka 11", answers11),
                new Question("Otázka 12", answers12),
                new Question("Otázka 13", answers13),
                new Question("Otázka 14", answers14),
                new Question("Otázka 15", answers15),
                new Question("Otázka 16", answers16),
                new Question("Otázka 17", answers17),
                new Question("Otázka 18", answers18),
                new Question("Otázka 19", answers19),
                new Question("Otázka 20", answers20)

                // Přidejte další otázky s odpověďmi...
        };
    }

    public Question[] getQuestions() {
        return questions;
    }
}