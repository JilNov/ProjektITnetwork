

// Enum pro označení sloupců odpovědí
public enum AnswerColumn {
    S1,
    S2,
    S3,
    S4
}


