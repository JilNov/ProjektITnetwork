class ResultAnalyzer {
    private int[] columnValues;

    public ResultAnalyzer(int[] columnValues) {
        this.columnValues = columnValues;
    }

    public void analyze() {
        // Váš další výpočet nebo analýza výsledků
        int[] multipliers = {1, 2, 3, 4};  // Čísla, kterými budeme násobit hodnoty sloupců S1 až S4

        int result = 0;

        for (int i = 0; i < columnValues.length; i++) {
            int columnValue = columnValues[i];
            int multiplier = multipliers[i];

            int multipliedValue = columnValue * multiplier;
            result += multipliedValue;
        }
    }

    public void printResults() {
        int totalResult = 0;

        for (int i = 0; i < columnValues.length; i++) {
            int columnValue = columnValues[i];
            int multiplier = i + 1;

            int multipliedValue = columnValue * multiplier;
            totalResult += multipliedValue;
        }

        System.out.println("Celkový výsledek 2 hodnota Efektivity: " + totalResult);
    }
}
