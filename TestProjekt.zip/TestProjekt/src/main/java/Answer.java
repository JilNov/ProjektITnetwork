// Třída pro odpověď
class Answer {
    private String text;
    private AnswerColumn column;
    private int count;
    public Answer(String text, AnswerColumn column) {
        this.text = text;
        this.column = column;
        this.count = 0;
    }

    public String getText() {
        return text;
    }

    public AnswerColumn getColumn() {
        return column;
    }
    public int getCount() {
        return count;
    }

    public void incrementCount() {
        count++;
    }
}