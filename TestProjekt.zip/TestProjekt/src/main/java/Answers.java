// Třída pro reprezentaci seznamu odpovědí k otázce
class Answers {
    private Answer[] answers;

    public Answers(Answer[] answers) {
        this.answers = answers;
    }

    public Answer[] getAnswers() {
        return answers;
    }
}