


import java.util.Scanner;

class Test {
    private Question[] questions;


    public Test(Question[] questions) {
        this.questions = questions;
    }

    public void run() {

        int answeredQuestions = 0; // Počet zodpovězených otázek
        Scanner scanner = new Scanner(System.in);

        System.out.println("Vítejte v testu!");

        String userInput = "";

        boolean testFinished = false;

        while (!testFinished) {
            // Projdeme všechny otázky
            for (Question question : questions) {
                boolean validAnswer = false;

                while (!validAnswer) {
                    System.out.println("\n\n Otázka " + question.getQuestionText());
                    for (Answer answer : question.getAnswers()) {
                        System.out.println("  " + answer.getText());
                    }

                    System.out.println("Napište svou odpověď (nebo napište 'konec' pro ukončení testu): ");
                    userInput = scanner.nextLine().toUpperCase();

                    if (userInput.equals("KONEC")) {
                        testFinished = true; // Pokud uživatel zvolí 'konec', přeskočíme zbytek cyklu a vytiskne výsledek
                        break;
                    }



                    // Zkontrolujeme, zda odpověď odpovídá uživatelově vstupu
                    for (int i = 0; i < question.getAnswers().length; i++) {
                        Answer answer = question.getAnswers()[i];
                        if (userInput.equals(String.valueOf((char) ('A' + i)))) {
                            answer.incrementCount();
                            validAnswer = true;
                            break;
                        }
                    }

                    if (!validAnswer) {
                        System.out.println("Neplatná odpověď! Zopakujte otázku.");
                    }

                }

                if (testFinished) {
                    break;
                }

                answeredQuestions++; // Zvýšíme počet zodpovězených otázek
            }

            if (testFinished || answeredQuestions == questions.length) {
                testFinished = true;  // Nastavit příznak ukončení testu
            }
        }

        // Výpis výsledků testu
        System.out.println("Test byl ukončen.");
        System.out.println("Celkový počet zodpovězených otázek: " + answeredQuestions + " z " + questions.length);

        int totalScore = 30; // Počáteční hodnota výsledného součtu

        for (AnswerColumn column : AnswerColumn.values()) {
            int columnValue = 0;
            for (Question question : questions) {
                if (question.getAnswers().length > 0) {
                    for (Answer answer : question.getAnswers()) {
                        if (answer.getColumn() == column) {
                            columnValue += answer.getCount(); // Přičítáme hodnotu z getCount()
                        }
                    }
                }
            }
            int adjustedValue = 5 - columnValue; // Rozdíl od čísla 5
            adjustedValue = adjustedValue < 0 ? 0 : adjustedValue; // Pokud je hodnota záporná, nastavíme ji na 0
           // System.out.println(column + ": " + adjustedValue); případné vypsání kontrolních hodnot sloupců S1-4
            totalScore -= adjustedValue; // Odečíst hodnotu od výsledného součtu
        }

        System.out.println("Celkový výsledek 1 hodnota flexibility: " + totalScore);

        // Druhá část: vytvoření instance ResultAnalyzer a volání jejích metod
        int[] columnValues = new int[4];
        for (int i = 0; i < columnValues.length; i++) {
            AnswerColumn column = AnswerColumn.values()[i];
            int columnValue = 0;
            for (Question question : questions) {
                for (Answer answer : question.getAnswers()) {
                    if (answer.getColumn() == column) {
                        columnValue += answer.getCount(); // Získání hodnoty z getCount()
                    }
                }
            }
            columnValues[i] = columnValue;
        }

        ResultAnalyzer resultAnalyzer = new ResultAnalyzer(columnValues);
        resultAnalyzer.analyze();
        resultAnalyzer.printResults();


    }
}
